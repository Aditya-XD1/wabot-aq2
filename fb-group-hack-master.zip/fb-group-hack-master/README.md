# fb-group-hack

# *how to run the script :  

1 - download it by: git clone https://github.com/Mr-NemrMedo/fb-group-hack
or download zip 

2 - put it in your file with another your tools and scripts 

3 - cd ( name file you puted the script in it) 

4 - ls 

5 - cd fb-group-hack

6 - ls 

7 - python2 fb-group-hack.py 

8 - follow the instructions in the script

# good luck  :)
